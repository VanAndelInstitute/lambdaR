/* Rversion.h.  Generated automatically. */
#ifndef R_VERSION_H
#define R_VERSION_H

#ifdef __cplusplus
extern "C" {
#endif

#define R_VERSION 262146
#define R_NICK "Taking Off Again"
#define R_Version(v,p,s) (((v) * 65536) + ((p) * 256) + (s))
#define R_MAJOR  "4"
#define R_MINOR  "0.2"
#define R_STATUS ""
#define R_YEAR   "2020"
#define R_MONTH  "06"
#define R_DAY    "22"
#define R_SVN_REVISION 78730
#define R_FILEVERSION    4,02,78730,0

#ifdef __cplusplus
}
#endif

#endif /* not R_VERSION_H */
